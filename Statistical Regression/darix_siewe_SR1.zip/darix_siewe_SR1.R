
install.packages("library(ggplot2)", dependencies = True)
library(ggplot2)

data <- read.csv("./data_purchase_behaviour.csv")
head(data)
tail(data)

## Perform a descriptive analysis of the variables in this dataset. Feel free to
# #use appropriate graphics to spicy your description#

## in our dataset the Marital status is numerical column
## the line bellow convert the columns Marital status into categorical status

## check the length of each columns
sapply(data, length)

## check the null value by columns data and handle this null value
missing_value <- function (col){
  return (sum(is.na(col)))
}

sapply(data, missing_value)

data$Marital_Status[data$Marital_Status == 0] <- "No"
data$Marital_Status[data$Marital_Status == 1] <- "Yes"
col <- colnames(data)
number_of_colums_without_ID_user <-  length(col)
summary(data[col[2:number_of_colums_without_ID_user]])

## summary data by Gender
by(data[col[2:number_of_colums_without_ID_user]], data$Gender,  summary)

## summary data by Marital Status
by(data[col[2:number_of_colums_without_ID_user]], data$Marital_Status,  summary)

## summary data by City Categories
by(data[col[2:number_of_colums_without_ID_user]], data$City_Category,  summary)

### bar Plots of Categorical data
### based on the graphic bellow the number of Male can be approximate the 3 times number of Female
barplot(table(data$Gender))

### bar Plots of Categorical data
### based on the graphic bellow the almost half are married
barplot(table(data$Marital_Status))

###  bar plots of City_Category
### 
barplot(table(data$City_Category))
        
### histogram of numerical variable
### the meaning of the histogram plot is the check graphically the distribution of our variable
### in our case we have just three numerical variable: Age_num, Purchase and Stay_In_Current_City_Years

ggplot(data, aes(x=Age_num), color= "blue") + geom_histogram(aes(y=..density..), color = "black", fill = "steelblue") +
  labs(x = "Age", y = "Frequency") +
  ggtitle("Histogram of  Age") +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal()
### based on the distribution of Age by gender we can see that Age By Gender have the almost the same distribution

ggplot(data, aes(x=Age_num, fill = Gender), color= Gender) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Age_num, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Age_num, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Age_num by Marital") +
  xlab("Age_num") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position
  theme(legend.position = "top")


ggplot(data, aes(x=Age_num, fill = Marital_Status), color= Marital_Status) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Age_num, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Age_num, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Age by Marital Status") +
  xlab("Age") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position 
  theme(legend.position = "top")

ggplot(data, aes(x=Age_num, fill = City_Category), color= City_Category) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Age_num, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Age_num, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Age_num by City_Category") +
  xlab("Age_num") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position
  theme(legend.position = "top")


## histogram of Purchase 

ggplot(data, aes(x=Purchase), color= "blue") + geom_histogram(aes(y=..density..),color = "black", fill = "steelblue") +
  labs(x = "Average Purchase", y = "Frequency") +
  ggtitle("Histogram of  Purchase") +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal()
### based on the distribution of Purchase by gender we can see that Age By Gender have the almost the same distribution

ggplot(data, aes(x=Purchase, fill = Gender), color= Gender) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Purchase, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Purchase, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  
  geom_density(alpha=.2, fill="#FF6666") 
  
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Purchase by Gender") +
  xlab("Age") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position
  theme(legend.position = "top")

ggplot(data, aes(x=Purchase, fill = Marital_Status), color= Gender) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Purchase, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Purchase, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Purchase by Marital") +
  xlab("Purchase") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position
  theme(legend.position = "top")

ggplot(data, aes(x=Purchase, fill = City_Category), color= City_Category) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Purchase, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Purchase, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Purchase by City Category") +
  xlab("Purchase") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position 
  theme(legend.position = "top")

## plots the box plot by Categorize Gender
ggplot(data, aes(x=Gender, y=Age_num, color=Gender)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

## plots the boxplot by Categorize Marital_Status
ggplot(data, aes(x=Marital_Status, y=Age_num, color=Marital_Status)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

ggplot(data, aes(x=Gender, y=Age_num, fill=Marital_Status)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

## plots the boxplot of Age by Categorize City Categories
ggplot(data, aes(x=City_Category, y=Age_num, fill=Gender)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

## plots the boxplot by Categorize Gender
ggplot(data, aes(x=Gender, y=Purchase, color=Gender)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

## plots the boxplot of Purchase by Categorize Marital_Status
ggplot(data, aes(x=Marital_Status, y=Purchase, color=Marital_Status)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)


## plots the boxplot of Purchase by Categorize City Categories
ggplot(data, aes(x=City_Category, y=Purchase, color=City_Category)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

ggplot(data, aes(x=Marital_Status, y=Purchase, fill=Gender)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

## Scater plot between independent vairbale Age_num, Stay_In_Current_City_Years and Purchase

ggplot(data, aes(x = Age_num, y = Purchase)) +
  geom_point(aes(color = Gender))

ggplot(data, aes(x = Age_num, y = Purchase)) +
  geom_point(aes(color = Marital_Status))


## we write our own function to calculate the correlation between each numerical variable in given data
custom_correlation <- function (data){
  numeric_cols <- data[sapply(data, is.numeric)] # filter only the numerical columns
  col_names <- colnames(numeric_cols) # get the columns names of the numerical columns
  N <- length(col_names) # get the length of the columns names
  cor_matrix <- matrix(NA, N, N) # create the empty matrix correlation
  for (i in 1:N){
    for (j in 1:N){
      n <- length(data[, i]) # get the length of the sample
      
      var_1 <- sum((numeric_cols[, i] -mean(numeric_cols[, i]))^2)/(n-1) # calculate the variance of the first variable
      
      var_2 <- sum((numeric_cols[, j] -mean(numeric_cols[, j]))^2)/(n-1) # calculate the variance of the second variable
      
      cov_1_2 <- sum((numeric_cols[, i]-mean(numeric_cols[, i]))*(numeric_cols[, j]-mean(numeric_cols[, j])))/(n-1) #calculate the covariance of the two variable
      cor_1_2 <- cov_1_2 /(var_1*var_2)^0.5 # calculate the correlation between two variable
      cor_matrix[i,j] <- cor_1_2 # update the value of correlation in the matrix of correlations
    }
  }
  colnames(cor_matrix) <- names(numeric_cols) # change the column name of the matrix correlation
  rownames(cor_matrix) <- names(numeric_cols) # change the row name of the matrix correlation
  print(cor_matrix)
}
## calculate the coefficient of correlation between each numerical variable
custom_correlation(data)

## 2) Use a simple linear regression model to investigate the dependence of the
## purchase amount on Age:

## we write our function to calculate de variance of numerical variable

custum_variance <- function(x){
  n <- length(x)
  var_x <- sum((x - mean(x))^2) / (n-1)
  return (var_x)
}

## we write our function to calcalute the co variance between two numerical variable
custom_covariance <- function (x, y){
  n <- length(x)
  cov_x_y <- sum((x-mean(x))*(y-mean(y)))/(n-1)
  return (cov_x_y)
}

## we write our own function to calculate the correlation between two numerical variable
custom_correlation_between_two <- function(x, y){
  n <- length(x)
  var_x <- custum_variance(x)
  var_y <- custum_variance(y)
  cov_x_y <- custom_covariance(x, y)
  cor_x_y <- cov_x_y /(var_x*var_y)^0.5
  return (cor_x_y)
}

### the coefficient of correlation between age and Purchase is 0.01563305 
### that value is very close to 0 that means independent variable Age and Dependent variable
### Purchase is not linearity independent because the exist a relation between coefficient
### of correlation and slope(the estimator of B1) of the simple linear model

cor_age_purchase <- custom_correlation_between_two(data$Age_num, data$Purchase)

### a) Fit the model by estimating the intercept, the slope, and the underlying
### uncertainties.

### we write our own function to calculate the slope and the intercept of our simple linear model
### function take two variable first is independent variable and second dependent variable and return 
### a vector (first intercept and the second slope)

calculate_intercept_slope <-function (x, y){
  slope <- sum((x-mean(x))*y)/sum((x-mean(x))^2)
  intercept <-mean(y) - slope*mean(x)
  return (c(intercept, slope))
}
parameter <- calculate_intercept_slope(data$Age_num, data$Purchase)
b_0 <- parameter[1] # intercept
b_1 <- parameter[2] # slope
b_0
b_1

### the underlying uncertainties.
### to answer to this question let's compute the value of 
### variance of intercept and slope and the covariance of intercept and slope
### we can resume this result into the matrix of covariance between intercept and slope

# this function is use to calculate the variance of our error


variance_of_error <- function (x, y){
  coef <- calculate_intercept_slope(x, y)
  error <- y - coef[1] - coef[2]*x
  var_error <- custum_variance(error)
  return (var_error)
}


var_error <- variance_of_error(data$Age_num, data$Purchase) ## the value of variance of our error

#This function is use to calculate the matrix of covariance between intercept and slope
estimate_covariance_matrix <- function (x, y){
  m <- matrix(NA, 2, 2)
  colnames(m) <- c("B0", "B1")
  rownames(m) <- c("B0", "B1")
  n <- length(x)
  v_error <- variance_of_error(x,y)
  v_b1 <- v_error /(sum((x-mean(x))^2))
  v_b0 <- v_error*(sum(x^2))/(n*sum((x-mean(x))^2))
  cov_b_0_b1 <- -v_error*(mean(x)/(sum((x-mean(x))^2)))
  m[1,1] <- v_b0
  m[2,2] <- v_b1
  m[1,2] <- cov_b_0_b1
  m[2,1] <- cov_b_0_b1
  return (m)
  
}

matrix_covariance_estimator <- estimate_covariance_matrix(data$Age_num, data$Purchase)
matrix_covariance_estimator

### in this step we need to estimate if B1 using hypothesis testing
### to achieve that let's use the theorem of central limit 
### we know that Age_num is almost distribution normal because we see this during our descriptive
### statistical when we have plot the histogram of Age_num variable


#The Central Limit Theorem predicts that as you perform more simulations and 
#increase the sample size, the distribution of these estimated slopes should 
#become approximately normal, centered around the true slope value (b_1).


test_central_limit_thoerem_on_slope <- function (x, y,  size_simualtions, n){
  ### the propulse of this function is to test the hypothesis of the slope
  ### in order to do that, we build we estimator that take random a sample in our data set
  ## that 
  b_1 <- 6.680612 #true value of slope
  b_0 <- 9037.936 #True value of intercept
  
  
  
  # Vector to store the estimated slopes
  slopes <- numeric(size_simualtions)
  Z <- numeric(size_simualtions) 
  param <-  calculate_intercept_slope(x, y) # get intercept and slope
  
  var_e <- variance_of_error(x, y) #calculate the variance or error model
  for( i in  1: size_simualtions){
      
    ##simulate the behavior of x
      x_sim <- sample(x, size = n, replace = FALSE)
      
      y_new <- param[1] + param[2]*x + rnorm(n, mean = 0, sd= sqrt(var_e))
      b_new <- calculate_intercept_slope(x, y_new)[2]
      slopes[i] <- b_new
      Z[i] <- (b_1 - b_new)/sqrt(matrix_covariance_estimator[1,1])
  }
  return (Z) ## estimator our on the random choice sample 
  
}

Z <- test_central_limit_thoerem_on_slope(data$Age_num, data$Purchase, 10000, 15000)

# Visualize the distribution of Z-statistics or slopes
hist(Z, main = "Distribution of Z-statistics for Slope", xlab = "Z-statistic")

### The Z-statistic is close to 0, it means that the estimated slope is close to the true slope, indicating no significant difference.
### it's not necessary to use t-distribution to test the significant of the estimate slope because the size of our sample is greater than 
### 30 and when n >=30 t-distribution is equivalent to normal distribution


alpha <- 0.05  # our significance level
z_alpha_half <- qnorm(1 - alpha/2)
### this is our interval of confidence
### 95% of confidence means if were repeat the experiment (or data collection process) many
### times and calculate teh confident interval B_1 each time We would expect 95% of the interval contain the true value of B_1
CI <- c(b_1 - z_alpha_half*sqrt(matrix_covariance_estimator[1,1]), b_1 + z_alpha_half*sqrt(matrix_covariance_estimator[1,1]))
CI

# Calculate the t-statistic for the slope
t_statistic <- b_1 / matrix_covariance_estimator[1,1]

# Degrees of freedom (n - 2 for simple linear regression)
df <- length(data$Age_num) - 2

# Calculate the p-value using the t-distribution
p_value <- 2 * (1 - pt(abs(t_statistic), df))

# Print the results
cat("Slope (b1):", b1, "\n")
cat("Standard Error of b1:", SE_b1, "\n")
cat("t-statistic:", t_statistic, "\n")
cat("p-value:", p_value, "\n")

## p-value is greater that 0.05 that means our variable is not significatif

model1 <- lm( Purchase ~ Age_num , data=data )
plot( model1$residuals ~ model1$fitted.values )

qqnorm( model1$residuals )
qqline( model1$residuals )
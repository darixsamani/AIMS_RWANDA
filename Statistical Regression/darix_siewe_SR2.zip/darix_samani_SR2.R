

install.packages("library(ggplot2)", dependencies = True)
library(ggplot2)
install.packages("e1071") 
install.packages("moments")

 ### check the summary of our model
data <- read.csv("./lending_dataset1_aggr.csv")
head(data)
tail(data)

summary(data)


## Perform a descriptive analysis of the variables in this dataset. Feel free to
# #use appropriate graphics to spicy your description#

## in our dataset the Marital status is numerical column
## the line bellow convert the columns Marital status into categorical status

## check the length of each columns
sapply(data, length)

## check the null value by columns data and handle this null value
## we have no null value in our dataset
missing_value <- function (col){
  return (sum(is.na(col)))
}

sapply(data, missing_value)

col <- colnames(data)
number_of_colums_without_ID_user <-  length(col)

## summary data by Gender
by(data[col[2:number_of_colums_without_ID_user]], data$Gender,  summary)

## summary data by Residence
by(data[col[2:number_of_colums_without_ID_user]], data$Residence,  summary)

## summary data by Residence
by(data[col[2:number_of_colums_without_ID_user]], data$LandOwner,  summary)

## summary data by Residence
by(data[col[2:number_of_colums_without_ID_user]], data$CarOwner,  summary)

## number of categorical variable
categorical_vars <- sapply(data, function(x) is.factor(x) | is.character(x))
sum(categorical_vars)

## this function is use to check if the variable is categorical

## number of count number of categories in Gender column
table(data$Gender)

## number of count number of categories in  Residence column
table(data$Residence)

## number of count number of categories in Gender column
table(data$Age)

## number of count number of categories in LandOwner column
table(data$LandOwner)

## number of count number of categories in CarOwner column
table(data$CarOwner)

### bar Plots of Categorical data
### barplot Gender
barplot(table(data$Gender))

### bar Plots of Categorical data
### barplot LandOwner
barplot(table(data$LandOwner))

### bar Plots of Categorical data
### barplot LandOwner
barplot(table(data$Residence))

### bar Plots of Categorical data
### barplot HomeOwner
barplot(table(data$HomeOwner))

### histogram of numerical variable
### the meaning of the histogram plot is the check graphically the distribution of our variable
### in our case we have just three numerical variable: Experience, Earnings and Defaults, Accounts, ObsRate
### based on this plot we can see that Experience seem follow the normal distribution
ggplot(data, aes(x=Experience), color= "blue") + geom_histogram(aes(y=..density..), color = "black", fill = "steelblue") +
  labs(x = "Experience", y = "Frequency") +
  ggtitle("Histogram of  Experience") +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal()


### distribution of Experience by Gender
ggplot(data, aes(x=Experience, fill = Gender), color= Gender) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Experience, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Experience, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Experience by Gender") +
  xlab("Experi") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position
  theme(legend.position = "top")

### distribution of Experience by Residence
ggplot(data, aes(x=Experience, fill = Residence), color= Residence) + geom_histogram(aes(y=..density..), binwidth = 10, position = "identity", alpha = 0.7) +
  # Add vertical lines for mean and median
  geom_vline(aes(xintercept = mean(Experience, na.rm = TRUE), color = "blue"),
             linetype = "dashed", size = 1) +
  geom_vline(aes(xintercept = median(Experience, na.rm = TRUE), color = "black"),
             linetype = "dotted", size = 1) +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal() +
  
  # Add titles and labels
  ggtitle("Distribution of  Experience by Residence") +
  xlab("Experience") +
  ylab("Frequency") +
  theme_minimal() +
  # Adjust legend position
  theme(legend.position = "top")


### based on this plot we can see that Earnings seem follow the normal distribution
ggplot(data, aes(x=Earnings), color= "blue") + geom_histogram(aes(y=..density..), color = "black", fill = "steelblue") +
  labs(x = "Earnings", y = "Frequency") +
  ggtitle("Histogram of  Earnings") +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal()


### based on this plot we can see that Defaults seem follow the normal distribution
ggplot(data, aes(x=Defaults), color= "blue") + geom_histogram(aes(y=..density..), color = "black", fill = "steelblue") +
  labs(x = "Defaults", y = "Frequency") +
  ggtitle("Histogram of  Defaults") +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal()

### based on this plot we can see that Accounts seem follow the normal distribution
ggplot(data, aes(x=Accounts), color= "blue") + geom_histogram(aes(y=..density..), color = "black", fill = "steelblue") +
  labs(x = "Accounts", y = "Frequency") +
  ggtitle("Histogram of  Accounts") +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal()

### based on this plot we can see that ObsRate seem follow the normal distribution
ggplot(data, aes(x=ObsRate), color= "blue") + geom_histogram(aes(y=..density..), color = "black", fill = "steelblue") +
  labs(x = "ObsRate", y = "Frequency") +
  ggtitle("Histogram of  ObsRate") +
  geom_density(alpha=.2, fill="#FF6666") +
  theme_minimal()



## plots the box plot by Categorize Gender
ggplot(data, aes(x=Gender, y=Experience, color=Gender)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

## plots the box plot by Categorize 
ggplot(data, aes(x=Gender, y=ObsRate, color=Gender)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)

## plots the box plot by Categorize Residence
ggplot(data, aes(x=Residence, y=ObsRate, color=Residence)) +
  geom_boxplot() + stat_summary(fun.y=mean, geom="point", shape=23, size=4)



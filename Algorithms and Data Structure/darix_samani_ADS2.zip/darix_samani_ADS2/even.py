#!/usr/bin/env python
# coding: utf-8
"""
To check if your solution is correct on a set run the following command(s) in terminal 

    python autograder.py -p even -s small

    python autograder.py -p even -s medium
    
    python autograder.py -p even -s large


run separately for each case
"""

import numpy as np


def even_odd(n, arr):
    """
    even_odd function 
    takes as input one test case 
    returns the solution for the test case (int)
    """
    m = max(arr)
    L = [[] for _ in range(m+1)]
    count_violation = 0
    for i in arr:
        if i%2!=0:
            for j in range(i):
                count_violation+=len(L[j])
        else:
            L[i].append(0)
    return count_violation

def run_code(in_name='datasets/small_even_odd_inversion.in'):
    """
    run_code function 
    takes one argument: the sample file to try
    loads the data and writes the solution to the output file (even_sol.out)
    """
    # Open input and output files
    fin = open(in_name, 'r')  # Do not change
    fout = open('datasets/even_sol.out', 'w')  # Do not change
    
    t = int(fin.readline().strip()) 
    
    for _ in range(t):
        n = int(fin.readline().strip())  
        if not(1<=n<=100000):
            return
        
        arr = list(map(int, fin.readline().strip().split()))  #
        
        result = even_odd(n, arr)
        
        fout.write(f"{result}\n")
    
    fin.close()
    fout.close()


#!/usr/bin/env python
# coding: utf-8
"""
To check if your solution is correct on a set run the following command(s) in terminal 

    python autograder.py -p connections -s small
    
    python autograder.py -p connections -s large


run separately for each case
"""

import numpy as np



from collections import deque, defaultdict
    

def close_connections(n,m, s, k , edges, fout): # Decide what arguments this function should take
    """
    close_connections function 
    takes as input one test case 
    returns the solution for the test case (int)
    """
    # Write your Solution Here! 

    # Build a adjacency list with default dict
    # with dict the access to element take contant time more fats than list
    
    graph = defaultdict(list)
    for a, b in edges:
        graph[a].append(b)
    # BFS setup
    queue = deque([s])
    distance = [-1] * (n + 1)  # -1 means the nodes is unvisited 
    distance[s] = 0
    reachable_count = 0
    
    while queue:
        current = queue.popleft()
        current_distance = distance[current]
        
        # stop if we have reached the maximum reachable nodes
        if current_distance > k:
            break
        
        # Count the current node as reachable
        reachable_count += 1
        
        # explore all neighor of current node
        for neighbor in graph[current]:
            if distance[neighbor] == -1:
                distance[neighbor] = current_distance + 1
                if distance[neighbor] <= k:
                    queue.append(neighbor)
    fout.write(f"{reachable_count}\n")
    
    


def run_code(in_name='datasets/connections_small.in'):
    """
    run_code function 
    takes one argument: the sample file to try
    loads the data and writes the solution to the output file (connections_sol.out)
    """
    fin = open(in_name, 'r')                  # Do not change
    fout = open('datasets/connections_sol.out', 'w')   # Do not change
    
    t = int(fin.readline().strip()) 
    for _ in range(t):
        n, m, s, k = map(int, fin.readline().strip().split())  
        if (not (1<=n<=10**5) or not(0<=m<=10**6) or not(1<=s<=n) or not(0<=k<=10**6)):
            return	
        edges = []
        for _ in range(m):
            a, b = map(int, fin.readline().split())
            if not(1<=a<=n) or not(1<=b<=n):
                return
            edges.append((a, b))
        close_connections(n,m,s,k,edges,fout)
    fin.close()
    fout.close()



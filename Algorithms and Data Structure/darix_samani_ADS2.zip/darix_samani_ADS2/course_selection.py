#!/usr/bin/env python
# coding: utf-8
"""
To check if your solution is correct on a set run the following command(s) in terminal 

    python autograder.py -p course -s small
    
    python autograder.py -p course -s large


run separately for each case

If you get an error: Segmentation Fault, run this command:

    ulimit -s unlimited 


"""

import numpy as np
import sys 
sys.setrecursionlimit(100000000)

from collections import deque, defaultdict

def course_selection(n, m, prerequisites):
    """
    course_selection function 
    takes as input one test case 
    returns the solution for the test case (list, or if there's no possible solution return str(IMPOSSIBLE))
    """
    # build a adjacent list
    graph = defaultdict(list)
    in_degree = [0] * (n + 1)  # in_degree of each node to zero
    
    # build our graph and calculate in_degree of each node
    for a, b in prerequisites:
        graph[a].append(b)  
        in_degree[b] += 1  # incrrease in_degree of the node b
    
    # find thenode with the in_degree = 0
    queue = deque()
    for course in range(1, n + 1):
        if in_degree[course] == 0:
            queue.append(course)
    
    # create our empty topological order to check if is it DAG
    topological_order = []
    while queue:
        course = queue.popleft()
        topological_order.append(course)
        
        # decrease in_degre of neightoring courses
        for neighbor in graph[course]:
            in_degree[neighbor] -= 1
            # added node to queue if in_degree == 0
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
    
    # check if topological_order have n node
    if len(topological_order) == n:
        return topological_order
    else:
        return "IMPOSSIBLE"

def run_code(in_name='datasets/course_selection_small.in'):
    """
    run_code function 
    takes one argument: the sample file to try
    loads the data and writes the solution to the output file (course_sol.out)
    """
    fin = open(in_name, 'r')  # Do not change
    fout = open('datasets/course_sol.out', 'w')  # Do not change
    
    t = int(fin.readline().strip())
    for _ in range(t):

        n, m = map(int, fin.readline().strip().split())  
        prerequisites = []
        
       
        for _ in range(m):
            a, b = map(int, fin.readline().strip().split())
            prerequisites.append((a, b))
        
        result = course_selection(n, m, prerequisites)
        
        if result == "IMPOSSIBLE":
            fout.write(result + "\n")
        else:
            fout.write(" ".join(map(str, result)) + "\n")
    
    fin.close()
    fout.close() 


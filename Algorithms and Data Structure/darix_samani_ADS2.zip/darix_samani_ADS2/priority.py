#!/usr/bin/env python
# coding: utf-8
"""
To check if your solution is correct on a set run the following command(s) in terminal 

    python autograder.py -p priority -s small
    
    python autograder.py -p priority -s large


run separately for each case
"""

import numpy as np

class PriorityQueue:
    def __init__(self):
        self.A = []  

    # Static functions to compute parent, left, and right children
    @staticmethod
    def parent(ind):
        return (ind - 1)//2

    @staticmethod
    def left(ind):
        return 2 * ind + 1

    @staticmethod
    def right(ind):
        return 2 * ind + 2

    
    def fix_heap(self, ind):
        l = self.left(ind)
        r = self.right(ind)
        largest = ind

        if l < len(self.A) and self.A[l] > self.A[largest]:
            largest = l
        
        if r < len(self.A) and self.A[r] > self.A[largest]:
            largest = r
        
        if largest != ind:
            self.A[ind], self.A[largest] = self.A[largest], self.A[ind]
            self.fix_heap(largest)

    
    def insert(self, x):
        if x<-10**6 and x>10**6:
            return None
        self.A.append(x)
        ind = len(self.A) - 1

        while ind > 0 and self.A[ind] > self.A[self.parent(ind)]:
            self.A[ind], self.A[self.parent(ind)] = self.A[self.parent(ind)], self.A[ind]
            ind = self.parent(ind)

    
    def extract_maximum(self):
        if len(self.A) == 0:
            return None 
        self.A[0], self.A[-1] = self.A[-1], self.A[0]
        m = self.A.pop(-1)
        self.fix_heap(0)
        return m

    def even_leaves(self):
        return sum(1 for x in self.A[len(self.A) // 2:] if x % 2 == 0)

def priority(individual_test, fout): # Decide what arguments you want this to take
    """
    priority function 
    takes as input one test case 
    returns the solution for the test case 
    """

    Q = PriorityQueue()
    for line in individual_test:
        if line[0] == "I":
                x = int(line[1])
                Q.insert(x)
        elif line[0] == "M":
            
            Q.extract_maximum()
        elif line[0] == "E":
            fout.write(f"{Q.even_leaves()}\n")

def run_code(in_name='datasets/priority_small.in'):
    """
    run_code function 
    takes one argument: the sample file to try
    loads the data and writes the solution to the output file (priority_sol.out)
    """

    fin = open(in_name, 'r')                  # Do not change
    fout = open('datasets/priority_sol.out', 'w')   # Do not change

    t = int(fin.readline().strip())
    for _ in range(t):
        k = int(fin.readline().strip())
        
        
        individu_test = []
        
        for _ in range(k):
            line = fin.readline().strip().split()
            individu_test.append(line)
        priority(individu_test, fout)




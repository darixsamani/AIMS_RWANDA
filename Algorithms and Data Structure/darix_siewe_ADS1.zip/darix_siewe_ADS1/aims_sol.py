""""
In this problem, you will try your solution on three different datasets: small, medium, and large
To test your solution on each one of them run the following in the terminal,
for small: 
    python autograder.py -p aims -s small

for medium: 
    python autograder.py -p aims -s medium

for large: 
    python autograder.py -p aims -s large

"""

def aims(n, S):
    #   Write your solution here!
    # The preprocessing is already done for you, implement your algorithm here, you're given one input case at a time through this function.
    # n is the length of the string S
    # return result
    setS = {"a","i","m","s"}
    Q =[1 if S[0] in setS else -1 ]
    for i in range(1,n):
        a_i_i = 1 if S[i] in setS else -1
        new_Q = max( Q[i-1] + a_i_i, a_i_i)
        Q.append(new_Q)
    result = max(Q)
    return 0 if result <0 else result

#################   DO NOT CHANGE BELOW ###########################

def run_code(name):
    fin = open(name, 'r')
    fout = open('datasets/aims/aims_sol.out', 'w')
    n_tests = int(fin.readline())
    for i in range(n_tests):
        n = int(fin.readline())
        S = fin.readline()[:-1]
        assert len(S) == n
        fout.write('%d\n' % aims(n, S))
    fin.close()
    fout.close()

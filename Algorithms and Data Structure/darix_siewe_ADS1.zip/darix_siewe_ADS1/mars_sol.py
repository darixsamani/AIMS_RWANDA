""""
In this problem, you will try your solution on two different datasets: small and large
To test your solution on each one of them run the following in the terminal,
for small: 
    python autograder.py -p mars -s small

for large: 
    python autograder.py -p mars -s large

    
Additionally, there's a third file called martian_example, which you do not need to test, you can use it to understand the problem better. 
"""


def number_of_leap(start_Y, end_Y):
    if end_Y > 220:
        if end_Y%10==0:
            number_of_leap = (end_Y)//2 - (start_Y+1)//2 + (end_Y)//10 - (start_Y+1)//10
        else:
            number_of_leap = (end_Y)//2 - (start_Y-1)//2 + (end_Y)//10 - (start_Y-1)//10
    else:
        if end_Y%10!=0:
            number_of_leap = (end_Y)//2 - (start_Y)//2 + (end_Y)//10 - (start_Y)//10
        else:
            number_of_leap = (end_Y)//2 - (start_Y-1)//2 + (end_Y)//10 - (start_Y-1)//10 - 1
    return number_of_leap, end_Y - start_Y -number_of_leap


def is_leap_year(year):
    """Check if a Martian year is a leap year."""
    return (year % 2 != 0) or (year % 10 == 0)

def get_month_days(month, year):
    """Return the number of sols in the given month of the given year."""
    
    if month == 6 or month == 12 or month == 18:
        return 27
    elif month == 24 and not is_leap_year(year):
        return 27
    else:
        return 28

def validate_date(day, month, year):
    """Check if the given Martian date is valid."""
    result = True
    if not (1 <= month <= 24) or not (1<= year <= 10**9):
        result = False
        
    if not (1 <= day <= get_month_days(month, year)):
        result = False
    return result



def mars(day, month, year):
    """Calculate the total number of sols from the base date 28.24.220."""
    base_year = 220
    base_month = 24
    base_day = 28
    base_weekday = 1  # Monday
    total_sols = 0
    if not validate_date(day, month, year):
        return -1
    nl, nnl = number_of_leap(1,year)
    total_sols = 669*nl + 668*nnl
    # get number of sols in each month.
    month_days = [28] * 24
    month_days[5] = month_days[11] = month_days[17] = month_days[23] = 27
    month_days[23] = 28 if is_leap_year(year) else 27

    # Sum up the days of all previous months.
    total_sols += sum(month_days[:month-1])

    # Add the day of the current month.
    total_sols += day - 1 
    return (total_sols + 1)%7
    
    


#################   DO NOT CHANGE BELOW ###########################

def run_code(name):
    fin = open(name, 'r')
    fout = open('datasets/mars/mars_sol.out', 'w')
    n_tests = int(fin.readline())
    for i in range(n_tests):
        d, m, y = map(int, fin.readline().split('.'))
        fout.write('%d\n' % mars(d, m, y))
    fin.close()
    fout.close()

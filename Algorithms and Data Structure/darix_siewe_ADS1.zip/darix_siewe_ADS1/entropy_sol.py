
""""
To test your solution run the following in the terminal: 
    python autograder.py -p entropy
"""
import numpy as np
def binary_entropy(p):
    return 0.0 if (p ==0 or p ==1) else -p*np.log2(p) - (1-p)*np.log2(1-p)

def entropy(alpha):


    #   Write your solution here!
    # The preprocessing is already done for you, implement your algorithm here, you're given one input case at a time through this function.
    # return result
    left = np.float(0)
    right = np.float(1)
    tolerance = 1e-6
    mid = 0
    while right - left > tolerance**2:
        mid = (left + right) /2 
        f_mid = binary_entropy(mid)
        
        # If the entropy at mid is close enough to alpha, exit early
        # to reduce the time complexity
        if abs(f_mid - alpha) < tolerance:
            return mid
        
        if f_mid < alpha:
            left = mid  
        elif f_mid > alpha:
            right = mid  
        else:
            return mid  # Exact match found
        
    return np.round((left + right)/ 2, 12)
    




#################   DO NOT CHANGE BELOW ###########################
INPUT_NAME = 'datasets/entropy/entropy.in'
OUTPUT_NAME = 'datasets/entropy/entropy_sol.out'
def run_code():
    f = open(INPUT_NAME, 'r')
    
    fout = open(OUTPUT_NAME, 'w')
    
    n_tests = int(f.readline())
    for i in range(n_tests):
        alpha = float(f.readline())
        p_str = entropy(alpha)
        fout.write(str(p_str) + '\n')
    f.close()
    fout.close()







